import javax.sound.midi.Soundbank;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import java.util.prefs.Preferences;

public class ExternalSort {

    public static void main(String[] args) throws IOException {


        long[] arr1=new long[125000000];

        int crt=0;
        int z=0;
        File file = new File("a.txt");

        BufferedReader xreader = null;
        FileOutputStream files = null;
        xreader=new BufferedReader(new FileReader(file));
        String txt=null;
        int k=0,q=0;
        for(int i=1;i<9;i++)
        {
            while(q<=1000000000)
            {
                if(k<125000000)
                {
                    txt = xreader.readLine();
                    arr1[k]=Long.valueOf(txt);
                    k++;
                    q++;
                }
                else
                {
                    Arrays.sort(arr1);
                    k=0;
                    BufferedWriter output = null;
                    try {
                        files = new FileOutputStream("" + i + ".txt");
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }

                    try {
                        File file1 = new File("" + i + ".txt");
                        output = new BufferedWriter(new FileWriter(file1));
                        while (  crt<125000000) {

                            output.write(String.valueOf(arr1[crt]));
                            output.newLine();
                            crt++;

                        }
                        file1.exists();
                        crt=0;

                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        if (output != null) {
                            output.close();

                        }


                    }

                    break;
                }
            }
            files.close();
        }

        xreader.close();

        try{

            File file3 = new File("a.txt");
            file3.exists();

            if(file3.delete()){
                System.out.println(file.getName() + " is deleted!");
            }else{
                System.out.println("Delete failed: File didn't delete");
            }
        }catch(Exception e){
            System.out.println("Exception occurred");
            e.printStackTrace();
        }

        long start =System.currentTimeMillis();
        BufferedReader nreader1 = null;
        BufferedReader nreader2=null;

        String txt1=null;
        String txt2=null;

        // MergeSort pb = new MergeSort();

        int t=0,y=9,h=0,e=0;
        for(int i=1;i<9;i+=2)
        {
            File n1file = null;
            BufferedWriter  bw=null;
            File nfile1 =null;
            File nfile2=null;
            try {


                n1file = new File("" + y + ".txt");

                nfile1 = new File("" + i + ".txt");
                nfile2 = new File("" + (i + 1) + ".txt");

                nreader1 = new BufferedReader(new FileReader(nfile1));
                nreader2 = new BufferedReader(new FileReader(nfile2));

                bw = new BufferedWriter(new FileWriter(n1file));
                t=0;
                e=0;
                h=0;
                String str1,str2;
                long m=0,n=0;
                str1=nreader1.readLine();
                str2=nreader2.readLine();
                while(t<250000000)
                {
                    if(str1!=null)
                        m=Long.parseLong(str1);
                    if(str2!=null)
                        n=Long.parseLong(str2);
                    if(h<125000000 && m<n )
                    {
                        bw.write(String.valueOf(m));
                        bw.newLine();
                        str1=nreader1.readLine();
                        t++;
                        h++;
                    }
                    else if(e<125000000 && m>n)
                    {
                        bw.write(String.valueOf(n));
                        bw.newLine();
                        str2=nreader2.readLine();
                        t++;
                        e++;
                    }
                    if(h==125000000)
                    {
                        bw.write(String.valueOf(n));
                        bw.newLine();
                        str2=nreader2.readLine();
                        t++;
                    }
                    else if(e==125000000)
                    {
                        bw.write(String.valueOf(m));
                        bw.newLine();
                        str1=nreader1.readLine();
                        t++;
                    }


                }
            }
            catch (Exception ee) {
                ee.printStackTrace();
            }
            finally
            {
                if (bw != null) {
                    bw.close();
                }
                if(nreader1!=null)
                {
                    nreader1.close();
                    nfile1.exists();
                    if(nfile1.delete())
                        System.out.println(nfile1.getName() + " is deleted!");

                }
                if(nreader2!=null)
                {
                    nreader2.close();
                    nfile2.exists();
                    if(nfile2.delete())
                        System.out.println(nfile2.getName() + " is deleted!");

                }
            }


            bw.close();
            y++;
        }

        t=0;
        e=0;
        h=0;
        for(int i=9;i<13;i+=2)
        {
            BufferedWriter  bw=null;
            File n1file = null;
            File nfile1=null;
            File nfile2=null;
            try {

                n1file = new File("" + y + ".txt");

                nfile1 = new File("" + i + ".txt");
                nfile2 = new File("" + (i + 1) + ".txt");

                nreader1 = new BufferedReader(new FileReader(nfile1));
                nreader2 = new BufferedReader(new FileReader(nfile2));

                bw = new BufferedWriter(new FileWriter(n1file));
                t=0;
                e=0;
                h=0;
                String str1,str2;
                long m=0,n=0;
                str1=nreader1.readLine();
                str2=nreader2.readLine();
                while(t<500000000)
                {
                    if(str1!=null)
                        m=Long.parseLong(str1);
                    if(str2!=null)
                        n=Long.parseLong(str2);
                    if(h<250000000 && m<n )
                    {
                        bw.write(String.valueOf(m));
                        bw.newLine();
                        str1=nreader1.readLine();
                        t++;
                        h++;
                    }
                    else if(e<250000000 && m>n)
                    {
                        bw.write(String.valueOf(n));
                        bw.newLine();
                        str2=nreader2.readLine();
                        t++;
                        e++;
                    }
                    if(h==250000000)
                    {
                        bw.write(String.valueOf(n));
                        bw.newLine();
                        str2=nreader2.readLine();
                        t++;
                    }
                    else if(e==250000000)
                    {
                        bw.write(String.valueOf(m));
                        bw.newLine();
                        str1=nreader1.readLine();
                        t++;
                    }
                }
            }
            catch (Exception ee) {
                ee.printStackTrace();
            }
            finally {
                if (bw != null) {
                    bw.close();
                }
                if(nreader1!=null)
                {
                    nreader1.close();
                    nfile1.exists();
                    if(nfile1.delete())
                        System.out.println(nfile1.getName() + " is deleted!");

                }
                if(nreader2!=null)
                {
                    nreader2.close();
                    nfile2.exists();
                    if(nfile2.delete())
                        System.out.println(nfile2.getName() + " is deleted!");

                }
            }
            bw.close();
            y++;
        }
        t=0;
        e=0;
        h=0;
        for(int i=13;i<15;i+=2)
        {
            BufferedWriter  bw=null;
            File n1file = null;
            File nfile1=null;
            File nfile2=null;
            try {
                n1file = new File("s.txt");

                nfile1 = new File("" + i + ".txt");
                nfile2 = new File("" + (i + 1) + ".txt");

                nreader1 = new BufferedReader(new FileReader(nfile1));
                nreader2 = new BufferedReader(new FileReader(nfile2));

                bw = new BufferedWriter(new FileWriter(n1file));
                t=0;
                e=0;
                h=0;
                String str1,str2;
                long m=0,n=0;
                str1=nreader1.readLine();
                str2=nreader2.readLine();
                while(t<1000000000)
                {
                    if(str1!=null)
                        m=Long.parseLong(str1);
                    if(str2!=null)
                        n=Long.parseLong(str2);
                    if(h<500000000 && m<n )
                    {
                        bw.write(String.valueOf(m));
                        bw.newLine();
                        str1=nreader1.readLine();
                        t++;
                        h++;
                    }
                    else if(e<500000000 && m>n)
                    {
                        bw.write(String.valueOf(n));
                        bw.newLine();
                        str2=nreader2.readLine();
                        t++;
                        e++;
                    }
                    if(h==500000000)
                    {
                        bw.write(String.valueOf(n));
                        bw.newLine();
                        str2=nreader2.readLine();
                        t++;
                    }
                    else if(e==500000000)
                    {
                        bw.write(String.valueOf(m));
                        bw.newLine();
                        str1=nreader1.readLine();
                        t++;
                    }
                }
            }
            catch (Exception ee) {
                ee.printStackTrace();
            }
            finally {
                if (bw != null) {
                    bw.close();
                }
                if(nreader1!=null)
                {
                    nreader1.close();
                    nfile1.exists();
                    if(nfile1.delete())
                        System.out.println(nfile1.getName() + " is deleted!");

                }
                if(nreader2!=null)
                {
                    nreader2.close();
                    nfile2.exists();
                    if(nfile2.delete())
                        System.out.println(nfile2.getName() + " is deleted!");

                }
            }

            bw.close();
            y++;
        }
        long end =System.currentTimeMillis();
        System.out.println(end-start);

    }

}

